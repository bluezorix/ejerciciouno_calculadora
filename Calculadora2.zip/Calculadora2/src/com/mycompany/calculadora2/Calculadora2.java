
package com.mycompany.calculadora2;
import com.mycompany.core.Calculadora;

public class Calculadora2 {
    public static void main(String[] args) {
        new Calculadora().iniciar();
    }
}
