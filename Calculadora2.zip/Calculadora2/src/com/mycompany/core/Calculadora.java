
package com.mycompany.core;

import com.mycompany.operaciones.*;
import com.mycompany.util.Consola;

public class Calculadora {

    public void iniciar() {
        double a = Consola.leerDouble("Ingrese el primer numero: ");
        double b = Consola.leerDouble("Ingrese el segundo numero: ");

        Operacion op = seleccionarOperacion(a, b);

        if (op != null) {
            System.out.println("Operacion: " + op.nombre());
            System.out.println("Resultado: " + op.calcular());
        }
    }

    private Operacion seleccionarOperacion(double a, double b) {
        System.out.println("1) Suma");
        System.out.println("2) Resta");
        System.out.println("3) Multiplicacion");
        System.out.println("4) Division");

        int opcion = Consola.leerInt("Opcion: ");

        switch (opcion) {
            case 1: return new Suma(a, b);
            case 2: return new Resta(a, b);
            case 3: return new Multiplicacion(a, b);
            case 4: return new Division(a, b);
            default:
                System.out.println("Opcion invalida");
                return null;
        }
    }
}
