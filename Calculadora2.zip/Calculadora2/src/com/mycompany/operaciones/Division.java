
package com.mycompany.operaciones;

public class Division extends Operacion {

    public Division(double a, double b) {
        super(a, b);
    }

    public double calcular() {
        if (b == 0) {
            System.out.println("No se puede dividir entre cero");
            return 0;
        }
        return a / b;
    }

    public String nombre() {
        return "Division";
    }
}
