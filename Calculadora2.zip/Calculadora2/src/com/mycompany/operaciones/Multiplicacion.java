
package com.mycompany.operaciones;

public class Multiplicacion extends Operacion {

    public Multiplicacion(double a, double b) {
        super(a, b);
    }

    public double calcular() {
        return a * b;
    }

    public String nombre() {
        return "Multiplicacion";
    }
}
