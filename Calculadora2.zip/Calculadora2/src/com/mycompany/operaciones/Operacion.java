
package com.mycompany.operaciones;

public abstract class Operacion {
    protected double a;
    protected double b;

    public Operacion(double a, double b) {
        this.a = a;
        this.b = b;
    }

    public abstract double calcular();
    public abstract String nombre();
}
