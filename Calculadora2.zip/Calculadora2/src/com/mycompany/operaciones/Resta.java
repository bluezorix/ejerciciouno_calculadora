
package com.mycompany.operaciones;

public class Resta extends Operacion {

    public Resta(double a, double b) {
        super(a, b);
    }

    public double calcular() {
        return a - b;
    }

    public String nombre() {
        return "Resta";
    }
}
