
package com.mycompany.operaciones;

public class Suma extends Operacion {

    public Suma(double a, double b) {
        super(a, b);
    }

    public double calcular() {
        return a + b;
    }

    public String nombre() {
        return "Suma";
    }
}
