
package com.mycompany.util;

import java.util.Scanner;

public class Consola {
    private static Scanner sc = new Scanner(System.in);

    public static double leerDouble(String mensaje) {
        System.out.print(mensaje);
        return sc.nextDouble();
    }

    public static int leerInt(String mensaje) {
        System.out.print(mensaje);
        return sc.nextInt();
    }
}
